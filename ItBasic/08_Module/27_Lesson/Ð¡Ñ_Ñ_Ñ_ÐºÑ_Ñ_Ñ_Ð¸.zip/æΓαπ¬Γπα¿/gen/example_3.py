pow2 = [2 ** x for x in range(10)]
print(pow2)

# [1, 2, 4, 8, 16, 32, 64, 128, 256, 512]

pow1 = []
for x in range(10):
    pow1.append(2 ** x)

print(pow1)

