list1 = [12, 34, 56, 67, 45, -11, -14]


def rev(lst):
    new_lst = lst[::-1]
    return new_lst


print(rev(list1))
