
text = '\"Don’t let the noise of others’ opinions drown out your own inner voice.\"' "\"Steve Jobs\""

def textFormat(text):
    text = text.split('."')
    print("Цитата: {}".format(text[0]))
    print("Автор: {}".format(text[1]))

textFormat(text)



