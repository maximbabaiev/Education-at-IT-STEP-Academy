first = [4, 5, 77, 3, 1, -1, -45]


def minNum(*args):
    return min(args)


print(minNum(*first))
