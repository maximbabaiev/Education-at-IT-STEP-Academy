mlist = [1, 2, 3, "pyton", 1.3, "ItStep", (1, 2, 4), {"key": 1}, [1, 3, 134]]
for i in mlist:
    print(type(i), i)