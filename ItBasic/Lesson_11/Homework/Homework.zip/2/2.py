city = ['Івано', '+', 'Франківськ']
city.remove('+')
city.insert(1, "-")
print(city[0] + city[1] + city[2])
